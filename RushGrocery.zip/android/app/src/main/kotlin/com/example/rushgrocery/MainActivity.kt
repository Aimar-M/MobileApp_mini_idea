package com.example.rushgrocery

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
